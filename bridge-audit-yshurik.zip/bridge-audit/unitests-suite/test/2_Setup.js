// Administration test suite

const Administration = artifacts.require("Administration");
const BAYL = artifacts.require("BAYL");
const BAYR = artifacts.require("BAYR");
const BAYF = artifacts.require("BAYF");
const Pool = artifacts.require("Pool");
const BitBayData = artifacts.require("BITBAY");

const { expectRevert, time } = require('@openzeppelin/test-helpers');
require('chai')
  .use(require('chai-as-promised'))
  .should()

function unit18(n) { return new web3.utils.BN(web3.utils.toWei(n.toString(), 'ether')); }
const maxuint = "115792089237316195423570985008687907853269984665640564039457584007913129639935";

let adm;
let bayl;
let bayr;
let bayf;
let pool;
let bitbaydata;

let init1 = async function() {
    adm = await Administration.deployed();
    bayl = await BAYL.deployed();
    bayr = await BAYR.deployed();
    bayf = await BAYF.deployed();
    pool = await Pool.deployed();
    bitbaydata = await BitBayData.deployed();
};

// EIP712 helper functions have been removed in favor of permit_helper

contract('Setup', (accounts) => {
  const [owner, user1, user2, spender] = accounts;
  const ZERO_ADDRESS = '0x0000000000000000000000000000000000000000';

  beforeEach(async () => {
    // Deploy fresh instances for each test
    if (bayl == null || bayl == undefined) {
      await init1();
    }
  });


  it('setup1', async () => {
    await adm.setProxy(bitbaydata.address);
    await bayl.setProxy(bitbaydata.address);
    await bayr.setProxy(bitbaydata.address);
    await bayf.setProxy(bitbaydata.address);
    await pool.setProxy(bitbaydata.address);
    await adm.changeLiquidityPool(pool.address);
    await bitbaydata.changeLiquidityPool(pool.address);
    await bitbaydata.changeMinter(adm.address);
    await bayl.setLiquidityPool(pool.address);
    await bayr.setLiquidityPool(pool.address);
  });


  it('test2', async () => {
    const proxy = await adm.proxy();
    proxy.should.equal(bitbaydata.address);

  });

  
});
