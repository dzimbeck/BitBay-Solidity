// Administration test suite

const Administration = artifacts.require("Administration");
const BitBayData = artifacts.require("BITBAY");
const BAYL = artifacts.require("BAYL");
const BAYR = artifacts.require("BAYR");
const BAYF = artifacts.require("BAYF");
const Pool = artifacts.require("Pool");
require('chai')
  .use(require('chai-as-promised'))
  .should()

const timeadv_helper = require("./helpers/timeAdvHelper");

function unit18(n) { return new web3.utils.BN(web3.utils.toWei(n.toString(), 'ether')); }

let adm;
let bitbaydata;
let bayl;
let bayr;
let bayf;
let pool;

let init1 = async function() {
  adm = await Administration.deployed();
  bitbaydata = await BitBayData.deployed();
  bayl = await BAYL.deployed();
  bayr = await BAYR.deployed();
  bayf = await BAYF.deployed();
  pool = await Pool.deployed();
};

contract('Administration (Curators)', (accounts) => {

  beforeEach(async function() {
    if (adm == null || adm == undefined) {
      await init1();
    }
  })

  it('setup1', async () => {
    await adm.setProxy(bitbaydata.address);
    await bayl.setProxy(bitbaydata.address);
    await bayr.setProxy(bitbaydata.address);
    await bayf.setProxy(bitbaydata.address);
    await pool.setProxy(bitbaydata.address);
    await adm.changeLiquidityPool(pool.address);
    await bitbaydata.changeLiquidityPool(pool.address);
    await bitbaydata.changeProxy(bayl.address, true);
    await bitbaydata.changeProxy(bayr.address, true);
    await bitbaydata.changeProxy(bayf.address, true);
    await bitbaydata.changeMinter(adm.address);
    await bayl.setLiquidityPool(pool.address);
    await bayr.setLiquidityPool(pool.address);
    await bayl.changeMinter(adm.address);
    await bayr.changeMinter(adm.address);
    await bayf.changeMinter(adm.address);
  });

  it('isCurator', async () => {
    const isCurator = await adm.isCurator(accounts[0]);
    isCurator.should.equal(true);
  });

  it('curators', async () => {
    const curator = await adm.curators(0);
    curator.should.equal(accounts[0]);
  });

  it('lockProxies', async () => {
    await adm.lockProxies(1209601,3);
  });

  it('advance 5400 seconds', async () => {
    await timeadv_helper.advanceTimeAndBlock(1209600+100);
  });

  it('should allow adding a new curator with weight', async () => {
    const newCurator = accounts[1];
    const weight = 50;
    
    // Initial state checks
    const initialIsCurator = await adm.isCurator(newCurator);
    const initialWeight = await adm.myweight(newCurator);
    const initialTotalVotes = await adm.totalvotes();
    
    // Change curator status and weight
    await adm.changecurator(newCurator, weight);
    
    // Verify the changes
    const isCuratorAfter = await adm.isCurator(newCurator);
    const weightAfter = await adm.myweight(newCurator);
    const totalVotesAfter = await adm.totalvotes();
    
    assert.equal(initialIsCurator, false, "Should not be curator initially");
    assert.equal(initialWeight.toString(), "0", "Initial weight should be 0");
    assert.equal(isCuratorAfter, true, "Should be curator after change");
    assert.equal(weightAfter.toString(), "50", "Weight should be updated");
    assert.equal(totalVotesAfter.toString(), (parseInt(initialTotalVotes) + weight).toString(), "Total votes should increase by weight");
  });

  it('advance 5400 seconds', async () => {
    await timeadv_helper.advanceTimeAndBlock(5400);
  });

  it('should allow removing a curator by setting weight to 0', async () => {
    const curatorToRemove = accounts[1];
    const initialWeight = await adm.myweight(curatorToRemove);
    const initialTotalVotes = await adm.totalvotes();
    
    // Remove curator by setting weight to 0
    await adm.changecurator(curatorToRemove, 0);
    
    // Verify the changes
    const isCuratorAfter = await adm.isCurator(curatorToRemove);
    const weightAfter = await adm.myweight(curatorToRemove);
    const totalVotesAfter = await adm.totalvotes();
    
    assert.equal(isCuratorAfter, false, "Should not be curator after removal");
    assert.equal(weightAfter.toString(), "0", "Weight should be 0");
    assert.equal(totalVotesAfter.toString(), (parseInt(initialTotalVotes) - parseInt(initialWeight)).toString(), "Total votes should decrease by removed weight");
  });

  it('should not allow setting weight above maxweight', async () => {
    const curator = accounts[2];
    const maxweight = await adm.maxweight();
    
    try {
      await adm.changecurator(curator, parseInt(maxweight) + 1);
      assert.fail("Should have thrown error");
    } catch (error) {
      assert(error.message.includes("revert"), "Expected revert error");
    }
  });

  it('should not allow setting weight to 1', async () => {
    const curator = accounts[2];
    
    try {
      await adm.changecurator(curator, 1);
      assert.fail("Should have thrown error");
    } catch (error) {
      assert(error.message.includes("revert"), "Expected revert error");
    }
  });

  it('advance 5400 seconds', async () => {
    await timeadv_helper.advanceTimeAndBlock(5400);
  });

  it('should allow adding a new curator with weight (2)', async () => {
    const newCurator = accounts[1];
    const weight = 50;
    
    // Initial state checks
    const initialIsCurator = await adm.isCurator(newCurator);
    const initialWeight = await adm.myweight(newCurator);
    const initialTotalVotes = await adm.totalvotes();
    
    // Change curator status and weight
    await adm.changecurator(newCurator, weight);
    
    // Verify the changes
    const isCuratorAfter = await adm.isCurator(newCurator);
    const weightAfter = await adm.myweight(newCurator);
    const totalVotesAfter = await adm.totalvotes();
    
    assert.equal(initialIsCurator, false, "Should not be curator initially");
    assert.equal(initialWeight.toString(), "0", "Initial weight should be 0");
    assert.equal(isCuratorAfter, true, "Should be curator after change");
    assert.equal(weightAfter.toString(), "50", "Weight should be updated");
    assert.equal(totalVotesAfter.toString(), (parseInt(initialTotalVotes) + weight).toString(), "Total votes should increase by weight");
  });

  it('advance 5400 seconds', async () => {
    await timeadv_helper.advanceTimeAndBlock(5400);
  });

  it('should maintain correct curators array', async () => {
    const newCurator = accounts[3];
    const weight = 5;
    
    // Add new curator
    await adm.changecurator(newCurator, weight);
    
    // Verify the changes
    const isCuratorAfter = await adm.isCurator(newCurator);
    const weightAfter = await adm.myweight(newCurator);
    const totalVotesAfter = await adm.totalvotes();
    
    // Get curators array length by counting until we get a revert
    let curatorsLength = 0;
    while (true) {
      try {
        await adm.curators(curatorsLength);
        curatorsLength++;
      } catch (error) {
        break;
      }
    }
    let found = false;
    
    // Check if new curator is in the array
    for(let i = 0; i < curatorsLength; i++) {
      const curator = await adm.curators(i);
      if(curator === newCurator) {
        found = true;
        break;
      }
    }
    
    assert.equal(found, true, "New curator should be in curators array");
  });

  it('should enforce voting time limits for curators', async () => {
    const curator = accounts[0];
    const voteType = 2; // curator change vote type
    
    const votetime = await adm.myvotetimes(curator, voteType);
    const timelimit = await adm.votetimelimit(voteType);
    
    assert(votetime.toString() !== "0", "Vote time should be set");
    assert(timelimit.toString() === "5400", "Default time limit should be 5400");
  });

  it('advance 5400 seconds', async () => {
    await timeadv_helper.advanceTimeAndBlock(5400);
  });

  it('remove curator (reset)', async () => {
    const curator = accounts[3];
    await adm.removeCurator(curator, true);
    await adm.removeCurator(curator, false); // with false, it should not revert
  });

  it('advance 15552000 seconds', async () => {
    await timeadv_helper.advanceTimeAndBlock(15552001);
  });

  it('remove curator', async () => {
    const curator = accounts[3];
    await adm.removeCurator(curator, false);
  });

});
