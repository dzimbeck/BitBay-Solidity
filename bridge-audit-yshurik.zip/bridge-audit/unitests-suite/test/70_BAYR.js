// BAYR test suite
const Administration = artifacts.require("Administration");
const BitBayData = artifacts.require("BITBAY");
const BAYL = artifacts.require("BAYL");
const BAYR = artifacts.require("BAYR");
const BAYF = artifacts.require("BAYF");
const Pool = artifacts.require("Pool");
const { expectRevert, time } = require('@openzeppelin/test-helpers');
require('chai')
  .use(require('chai-as-promised'))
  .should();

const timeadv_helper = require("./helpers/timeAdvHelper");
const permit_helper = require("./helpers/permitHelper");

let adm;
let bitbaydata;
let bayl;
let bayr;
let bayf;
let pool;
let tdelta = 0;

let init1 = async function() {
  adm = await Administration.deployed();
  bitbaydata = await BitBayData.deployed();
  bayl = await BAYL.deployed();
  bayr = await BAYR.deployed();
  bayf = await BAYF.deployed();
  pool = await Pool.deployed();
};

contract('BAYR', (accounts) => {
  const [owner, user1, user2, spender] = accounts;
  const ZERO_ADDRESS = '0x0000000000000000000000000000000000000000';

  beforeEach(async () => {
    if (bayr == null || bayr == undefined) {
      await init1();
    }
  });

  it('changeMinter', async () => {
    await bayr.changeMinter(accounts[1], { from: accounts[0] });
  });

  it('changeMinter', async () => {
    await bayr.changeMinter(accounts[0], { from: accounts[1] });
  });

  it('changeMinter', async () => {
    await bayr.changeMinter(ZERO_ADDRESS, { from: accounts[0] });
  });

  it('setup2', async () => {
    await adm.setProxy(bitbaydata.address);
    await bayl.setProxy(bitbaydata.address);
    await bayr.setProxy(bitbaydata.address);
    await bayf.setProxy(bitbaydata.address);
    await pool.setProxy(bitbaydata.address);
    await adm.changeLiquidityPool(pool.address);
    await bitbaydata.changeLiquidityPool(pool.address);
    await bitbaydata.changeProxy(bayl.address, true);
    await bitbaydata.changeProxy(bayr.address, true);
    await bitbaydata.changeProxy(bayf.address, true);
    await bitbaydata.changeMinter(adm.address);
    await bayl.changeMinter(adm.address);
    await bayr.changeMinter(adm.address);
    await bayf.changeMinter(adm.address);
  });

  it('has correct name', async () => {
    const name = await bayr.name();
    name.should.equal('BitBay Reserve');
  });

  it('has correct symbol', async () => {
    const symbol = await bayr.symbol();
    symbol.should.equal('BAYR');
  });

  it('has correct decimals', async () => {
    const decimals = await bayr.decimals();
    decimals.toString().should.equal('8');
  });

  it('has correct version', async () => {
    const version = await bayr.version();
    version.should.equal('1');
  });

  it('returns balance of address', async () => {
    const balance = await bayr.balanceOf(owner);
    assert(balance.toString() !== undefined, "Balance should be defined");
  });

  it('setActive', async () => {
    await adm.setActive(true);
  });

  it('disableMinting', async () => { 
    await adm.disableMinting();
  });

  it('redeemTX', async () => { 
    const txid = "a627715744a9a5479fdabb5fa23570ffbb775d2814ae98b042c61eee4302e708";
    const sender = accounts[0];
    const reserve = [
      0,1000000,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,1000000,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0];
    const leaf = web3.utils.keccak256(web3.eth.abi.encodeParameters(
      ['address', 'uint256[38]', 'string'],
      [sender, reserve, txid]
    ));
    const root = leaf;
    await adm.addMerkle(root, 0);
    // wait 2x 43200
    await timeadv_helper.advanceTimeAndBlock(86400+100);
    tdelta += 86400+100;
    const proof = [];
    await adm.redeemTX(root, proof, reserve, txid);
    const balanceL = await bayl.balanceOf(accounts[0]);
    const balanceR = await bayr.balanceOf(accounts[0]);
    const balanceF = await bayf.balanceOf(accounts[0]);
    assert.equal(balanceL.toString(), "2000000");
    assert.equal(balanceR.toString(), "0");
    assert.equal(balanceF.toString(), "0");
    // move peg
  });

  it('setSupply', async () => { 
    await adm.setSupply(40, []);
    await timeadv_helper.advanceTimeAndBlock(5400);
    tdelta += 5400;
    const balanceL = await bayl.balanceOf(accounts[0]);
    const balanceR = await bayr.balanceOf(accounts[0]);
    const balanceF = await bayf.balanceOf(accounts[0]);
    assert.equal(balanceL.toString(), "1000000");
    assert.equal(balanceR.toString(), "1000000");
    assert.equal(balanceF.toString(), "0");
  });

  it('allows transfer between accounts', async () => {
    const amount = web3.utils.toBN('100000');
    await bayr.transfer(user1, amount, { from: owner });
    const balance = await bayf.balanceOf(user1);
    assert.equal(balance.toString(), amount.toString());
    const balanceL = await bayl.balanceOf(accounts[0]);
    const balanceR = await bayr.balanceOf(accounts[0]);
    const balanceF = await bayf.balanceOf(user1);
    assert.equal(balanceL.toString(), "1000000");
    assert.equal(balanceR.toString(), "900000");
    assert.equal(balanceF.toString(), "100000");
  });

  it('allows unfreeze', async () => {
    {
      const balanceL = await bayl.balanceOf(user1);
      const balanceR = await bayr.balanceOf(user1);
      const balanceF = await bayf.balanceOf(user1);
      assert.equal(balanceL.toString(), "0");
      assert.equal(balanceR.toString(), "0");
      assert.equal(balanceF.toString(), "100000");
    }
    await bayf.transfer(user1, 0, { from: user1 });
    {
      const balanceL = await bayl.balanceOf(user1);
      const balanceR = await bayr.balanceOf(user1);
      const balanceF = await bayf.balanceOf(user1);
      assert.equal(balanceL.toString(), "0");
      assert.equal(balanceR.toString(), "0");
      assert.equal(balanceF.toString(), "100000");
    }
    await timeadv_helper.advanceTimeAndBlock(500);
    tdelta += 500;
    await bayf.transfer(user1, 0, { from: user1 });
    {
      const balanceL = await bayl.balanceOf(user1);
      const balanceR = await bayr.balanceOf(user1);
      const balanceF = await bayf.balanceOf(user1);
      assert.equal(balanceL.toString(), "0");
      assert.equal(balanceR.toString(), "0");
      assert.equal(balanceF.toString(), "100000");
    }
    await timeadv_helper.advanceTimeAndBlock(160);
    tdelta += 160;
    await bayf.transfer(user1, 0, { from: user1 });
    {
      const balanceL = await bayl.balanceOf(user1);
      const balanceR = await bayr.balanceOf(user1);
      const balanceF = await bayf.balanceOf(user1);
      assert.equal(balanceL.toString(), "0");
      assert.equal(balanceR.toString(), "100000");
      assert.equal(balanceF.toString(), "0");
    }
  });


  it('allows approval and transferFrom', async () => {
    const amount = web3.utils.toBN('100000');
    await bayr.approve(spender, amount, { from: owner });
    const allowance = await bayr.allowance(owner, spender);
    assert.equal(allowance.toString(), amount.toString());
    
    await bayr.transferFrom(owner, user2, amount, { from: spender });
    const balance = await bayf.balanceOf(user2);
    assert.equal(balance.toString(), amount.toString());
  });

  it('prevents approval to zero address', async () => {
    const amount = web3.utils.toWei('1', 'ether');
    await expectRevert(
      bayr.approve(ZERO_ADDRESS, amount, { from: owner }),
      'revert'
    );
  });

  it('allows transfers to non-contract addresses', async () => {
    await bayr.checkAddress(user1, false);
    
  });

  // it('validates contract addresses', async () => {
  //   await bayr.checkAddress(bitbaydata.address, false);
  // });

  it('handles sync parameter correctly', async () => {
    await bayr.checkAddress(user1, true);
  });

  it('check totalSupply', async () => {
    const totalSupplyL = await bayl.totalSupply();
    assert.equal(totalSupplyL.toString(), "100000000000000000");
    const totalSupplyR = await bayr.totalSupply();
    assert.equal(totalSupplyR.toString(), "86602032514203814");
  });

  let bayr_domain;
  let bayr_domain_sep;

  it('bayr domain separator', async () => {
    const d2 = await bayr.DOMAIN_SEPARATOR();
    const chainId = config.network == "soliditycoverage" ? 1 : await web3.eth.getChainId(); // warning: the network can be different during running coverage: 1 (soliditycoverage)
    const name = await bayr.name();
    const version = await bayr.version();
    bayr_domain_sep = permit_helper.domainSep(name, version, chainId, bayr.address);
    bayr_domain = { name: name, version: version, chainId: chainId, verifyingContract: bayr.address };
    assert.equal(bayr_domain_sep, d2, "domain separator");
  });

  const maxuint = "115792089237316195423570985008687907853269984665640564039457584007913129639935";
  function ether(n) { return new web3.utils.BN(web3.utils.toWei(n.toString(), 'ether')); }

  it('move-6-permit', async () => {
    const n1 = await bayr.nonces(accounts[0]);
    const sigp_tm = await permit_helper.makeEipPermitExtSignData(bayr_domain, accounts[0], accounts[2], n1, maxuint, 0);
    await bayr.approve(accounts[2], ether(0), { from: accounts[0] });
    await bayr.permit(accounts[0], accounts[2], maxuint, 0, sigp_tm.v, sigp_tm.r, sigp_tm.s, { from: accounts[3] });
    {
      const a1 = await bayr.allowance(accounts[0], accounts[2]);
      assert.equal(a1.toString(), maxuint, "match allowance of user0 for user2");
    }
  });


  it('accepts valid permit signature', async () => {
    const value = web3.utils.toBN('1000000000').toString();
    const deadline = Math.floor(Date.now() / 1000) + 3600 +tdelta; // 1 hour from now
    const nonce = (await bayr.nonces(owner)).toString();      
    // Generate signature using permit_helper
    const sig = await permit_helper.makeEipPermitExtSignData(
      bayr_domain,
      owner,
      spender,
      nonce,
      value,
      deadline
    );
    // Call permit function with the generated signature
    await bayr.permit(owner, spender, value, deadline, sig.v, sig.r, sig.s);      
    // Check if allowance was set correctly
    const allowance = await bayr.allowance(owner, spender);
    assert.equal(allowance.toString(), value.toString(), "Allowance not set correctly after permit");
  });

  it('rejects expired permit', async () => {
    const value = web3.utils.toBN('1000000000').toString();
    const deadline = Math.floor(Date.now() / 1000) - 3600 +tdelta; // 1 hour in the past
    const nonce = (await bayr.nonces(owner)).toString();      
    // Generate signature using permit_helper
    const sig = await permit_helper.makeEipPermitExtSignData(
      bayr_domain,
      owner,
      spender,
      nonce,
      value,
      deadline
    );
    // Call permit function with the generated signature
    await expectRevert(
      bayr.permit(owner, spender, value, deadline, sig.v, sig.r, sig.s),
      'Permit-expired'
    );
  });

  it('rejects invalid signature', async () => {
    const value = web3.utils.toBN('1000000000');
    const deadline = Math.floor(Date.now() / 1000) + 3600 +tdelta; // 1 hour from now
    
    // Use incorrect v, r, s values
    await expectRevert(
      bayr.permit(owner, spender, value, deadline, 27, '0x0000000000000000000000000000000000000000000000000000000000000000', '0x0000000000000000000000000000000000000000000000000000000000000000'),
      'Invalid-permit'
    );
  });

});
