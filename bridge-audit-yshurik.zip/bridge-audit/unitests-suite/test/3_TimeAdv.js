
require('chai')
  .use(require('chai-as-promised'))
  .should()

const timeadv_helper = require("./helpers/timeAdvHelper");

contract('TimeAdv', (accounts) => {

  it("should advance the blockchain forward a block", async () =>{
      let block = await web3.eth.getBlock('latest');
      const originalBlockHash = block.hash;
      await timeadv_helper.advanceBlock();
      block = await web3.eth.getBlock('latest');
      let newBlockHash = block.hash;
      assert.notEqual(originalBlockHash, newBlockHash);
  });

  it("should be able to advance time and block together", async () => {
      const advancement = 600;
      const originalBlock = await web3.eth.getBlock('latest');
      const newBlock = await timeadv_helper.advanceTimeAndBlock(advancement);
      const timeDiff = newBlock.timestamp - originalBlock.timestamp;
      assert.isTrue(timeDiff+1 >= advancement);
  });


});
