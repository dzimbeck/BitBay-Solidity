// Administration test suite

const Permit = artifacts.require("Permit");

const { expectRevert, time } = require('@openzeppelin/test-helpers');
require('chai')
  .use(require('chai-as-promised'))
  .should()

const permit_helper = require("./helpers/permitHelper");

function unit18(n) { return new web3.utils.BN(web3.utils.toWei(n.toString(), 'ether')); }

let permit;

let init1 = async function() {
  permit = await Permit.deployed();
};

// EIP712 helper functions have been removed in favor of permit_helper

contract('Permit', (accounts) => {
  const [owner, user1, user2, spender] = accounts;
  const ZERO_ADDRESS = '0x0000000000000000000000000000000000000000';

  let permit_domain;
  let permit_domain_sep;

  beforeEach(async () => {
    // Deploy fresh instances for each test
    if (permit == null || permit == undefined) {
      await init1();
    }
  });


  it('permit domain separator', async () => {
    const d2 = await permit.DOMAIN_SEPARATOR();
    // warning: the network can be different during running coverage: 1 (soliditycoverage)
    const chainId = config.network == "soliditycoverage" ? 1 : await web3.eth.getChainId(); 
    const name = await permit.name();
    const version = await permit.version();
    permit_domain_sep = permit_helper.domainSep(name, version, chainId, permit.address);
    permit_domain = { name: name, version: version, chainId: chainId.toString(), verifyingContract: permit.address };
    assert.equal(permit_domain_sep, d2, "domain separator");
  });

  const maxuint = "115792089237316195423570985008687907853269984665640564039457584007913129639935";

  it('permit test', async () => {
    const n1 = await permit.nonces(accounts[0]);
    const sigp_tm = await permit_helper.makeEipPermitExtSignData(permit_domain, accounts[0], accounts[2], n1, maxuint, 0);
    await permit.permit(accounts[0], accounts[2], maxuint, 0, sigp_tm.v, sigp_tm.r, sigp_tm.s, { from: accounts[3] });
  });

  
});
