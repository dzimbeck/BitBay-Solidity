// Administration test suite

const Administration = artifacts.require("Administration");
const BitBayData = artifacts.require("BITBAY");
const BAYL = artifacts.require("BAYL");
const BAYR = artifacts.require("BAYR");
const BAYF = artifacts.require("BAYF");
const Pool = artifacts.require("Pool");
require('chai')
  .use(require('chai-as-promised'))
  .should()

const timeadv_helper = require("./helpers/timeAdvHelper");

function unit18(n) { return new web3.utils.BN(web3.utils.toWei(n.toString(), 'ether')); }

let adm;
let bitbaydata;
let bayl;
let bayr;
let bayf;
let pool;

let init1 = async function() {
  adm = await Administration.deployed();
  bitbaydata = await BitBayData.deployed();
  bayl = await BAYL.deployed();
  bayr = await BAYR.deployed();
  bayf = await BAYF.deployed();
  pool = await Pool.deployed();
};

contract('BAYF', (accounts) => {

  beforeEach(async function() {
    if (bayf == null || bayf == undefined) {
      await init1();
    }
  });

  it('minter', async () => {
    const minter = await bayf.minter();
    minter.should.equal(accounts[0]);
  });

  it('changeMinter', async () => {
    await bayf.changeMinter(accounts[1], { from: accounts[0] });
  });

  it('changeMinter', async () => {
    await bayf.changeMinter(accounts[0], { from: accounts[1] });
  });

  it('lockProxies', async () => {
    await bayf.lockProxies(1);
  });

  it('advance 5400 seconds', async () => {
    await timeadv_helper.advanceTimeAndBlock(1209600+100);
  });

  it('setup1', async () => {
    await adm.setProxy(bitbaydata.address);
    await bayl.setProxy(bitbaydata.address);
    await bayr.setProxy(bitbaydata.address);
    await bayf.setProxy(bitbaydata.address);
    await pool.setProxy(bitbaydata.address);
    await adm.changeLiquidityPool(pool.address);
    await bitbaydata.changeLiquidityPool(pool.address);
    await bitbaydata.changeProxy(bayl.address, true);
    await bitbaydata.changeProxy(bayr.address, true);
    await bitbaydata.changeProxy(bayf.address, true);
    await bitbaydata.changeMinter(adm.address);
    await bayl.changeMinter(adm.address);
    await bayr.changeMinter(adm.address);
    await bayf.changeMinter(adm.address);
  });

  it('name', async () => {
    const name = await bayf.name();
    name.should.equal('BitBay Frozen');
  });

  it('totalSupply', async () => {
    const totalSupply = await bayf.totalSupply();
    assert.equal(totalSupply.toString(), "100000000000000000");
  });


  it('proxy', async () => {
    const proxy = await bayf.proxy();
    proxy.should.equal(bitbaydata.address);
  });

  it('balanceOf', async () => {
    const balance = await bayf.balanceOf(accounts[0]);
    assert.equal(balance.toString(), '0', "balance should be 0");
  });

  it('transfer', async () => {
    await bayf.transfer(accounts[0], 0, { from: accounts[0] });
  });

});
