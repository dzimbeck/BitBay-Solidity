
let sha3 = require('js-sha3');
let ethers = require('ethers');

/*!
keccak256(abi.encode(
  keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"),
  keccak256(bytes(name)),
  keccak256(bytes(version)),
  chainId_,
  address(this)
)
*/
let domainSep = function(name, version, chainid, contract) {
  //data1
  const callsig = "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)";
  const callsig_hex = web3.utils.stringToHex(callsig);
  const callsig_data = web3.utils.hexToBytes(callsig_hex);
  const h1 = sha3.keccak256(callsig_data);
  const h1_data = web3.utils.hexToBytes("0x"+h1);
  //data2
  const name_hex = web3.utils.stringToHex(name);
  const name_data = web3.utils.hexToBytes(name_hex);
  const h2 = sha3.keccak256(name_data);
  const h2_data = web3.utils.hexToBytes("0x"+h2);
  //data3
  const version_hex = web3.utils.stringToHex(version);
  const version_data = web3.utils.hexToBytes(version_hex);
  const h3 = sha3.keccak256(version_data);
  const h3_data = web3.utils.hexToBytes("0x"+h3);
  //data4
  const chainid_hex = web3.utils.padLeft(web3.utils.numberToHex(chainid), 64);
  const chainid_data = web3.utils.hexToBytes(chainid_hex);
  //data5
  const addr1_pre = web3.utils.hexToBytes(contract);
  const addr1_hex = web3.utils.padLeft(web3.utils.bytesToHex(addr1_pre), 64);
  const addr1_data = web3.utils.hexToBytes(addr1_hex);
  //join 
  //console.log("lo data", web3.utils.bytesToHex(h1_data.concat(h2_data).concat(h3_data).concat(chainid_data).concat(addr1_data)));
  const h = sha3.keccak256(h1_data.concat(h2_data).concat(h3_data).concat(chainid_data).concat(addr1_data));
  return "0x"+h;
}

const EIP712Domain = [
  { name: "name", type: "string" },
  { name: "version", type: "string" },
  { name: "chainId", type: "uint256" },
  { name: "verifyingContract", type: "address" },
];

const makeDaiPermitData = function(message /*: DaiPermitMessage*/, domain /*: Domain*/) {
  const typedData = {
    types: {
      EIP712Domain,
      Permit: [
        { name: "holder", type: "address" },
        { name: "spender", type: "address" },
        { name: "nonce", type: "uint256" },
        { name: "expiry", type: "uint256" },
        { name: "allowed", type: "bool" },
      ],
    },
    primaryType: "Permit",
    domain,
    message,
  };
  return typedData;
};

const makeEipPermitData = function(message /*: EipPermitMessage*/, domain /*: Domain*/) {
  const typedData = {
    types: {
      EIP712Domain,
      Permit: [
        { name: "owner", type: "address" },
        { name: "spender", type: "address" },
        { name: "value", type: "uint256" },
        { name: "nonce", type: "uint256" },
        { name: "deadline", type: "uint256" },
      ],
    },
    primaryType: "Permit",
    domain,
    message,
  };
  return typedData;
};

signTypedData = (web3, from, data) => {
  return new Promise(async (resolve, reject) => {
    function cb(err, result) {
      if (err) {
        return reject(err);
      }
      if (result.error) {
        return reject(result.error);
      }

      const sig = result.result;
      const sig0 = sig.substring(2);
      const r = "0x" + sig0.substring(0, 64);
      const s = "0x" + sig0.substring(64, 128);
      const v = parseInt(sig0.substring(128, 130), 16);

      resolve({
        data,
        sig,
        v, r, s
      });
    }
    if (web3.currentProvider.isMetaMask) {
      web3.currentProvider.sendAsync({
        jsonrpc: "2.0",
        method: "eth_signTypedData_v3",
        params: [from, JSON.stringify(data)],
        id: new Date().getTime()
      }, cb);
    } else {
      let send = web3.currentProvider.sendAsync;
      if (!send) send = web3.currentProvider.send;
      send.bind(web3.currentProvider)({
        jsonrpc: "2.0",
        method: "eth_signTypedData",
        params: [from, data],
        id: new Date().getTime()
      }, cb);
    }
  });
};

let makePermitExtSignData = async function(domain, acc_addr, spender, nonce) {
  const permit_message = {
    holder: acc_addr,
    spender,
    nonce,
    expiry: 0,
    allowed: true,
  };
  const permit_data = makeDaiPermitData(permit_message, domain);
  const sigtm = await signTypedData(web3, acc_addr, permit_data);
  return sigtm;
}

let makeEipPermitExtSignData = async function(domain, acc_addr, spender, nonce, value, deadline) {
  const permit_message = {
    owner: acc_addr,
    spender,
    value,
    nonce,
    deadline
  };
  const permit_data = makeEipPermitData(permit_message, domain);
  const sigtm = await signTypedData(web3, acc_addr, permit_data);
  return sigtm;
}

let makePermitExtSign = async function(domain, acc_addr, spender, nonce) {
  const sigtm = await makePermitExtSignData(domain, acc_addr, spender, nonce);
  return sigtm.sig;
}

let makeEipPermitExtSign = async function(domain, acc_addr, spender, nonce, value, deadline) {
  const sigtm = await makeEipPermitExtSignData(domain, acc_addr, spender, nonce, value, deadline);
  return sigtm.sig;
}

let permitDigest1 = function(ds, holder, spender, nonce, expiry, allowed) {
  const d1 = "\x19\x01";
  const d1_hex = web3.utils.stringToHex(d1);
  const d1_data = web3.utils.hexToBytes(d1_hex);
  const ds_data = web3.utils.hexToBytes(ds);
  //h1
  const th_hex = "0xea2aa0a1be11a07ed86d755c93467f4f82362b452371d1ba94d1715123511acb";
  const th_data = web3.utils.hexToBytes(th_hex);
  const addr1_pre = web3.utils.hexToBytes(holder);
  const addr1_hex = web3.utils.padLeft(web3.utils.bytesToHex(addr1_pre), 64);
  const addr1_data = web3.utils.hexToBytes(addr1_hex);
  const addr2_pre = web3.utils.hexToBytes(spender);
  const addr2_hex = web3.utils.padLeft(web3.utils.bytesToHex(addr2_pre), 64);
  const addr2_data = web3.utils.hexToBytes(addr2_hex);
  const nonce_hex = web3.utils.padLeft(web3.utils.numberToHex(nonce), 64);
  const nonce_data = web3.utils.hexToBytes(nonce_hex);
  const expiry_hex = web3.utils.padLeft(web3.utils.numberToHex(expiry), 64);
  const expiry_data = web3.utils.hexToBytes(expiry_hex);
  const allowed_hex = web3.utils.padLeft(web3.utils.numberToHex(allowed), 64);
  const allowed_data = web3.utils.hexToBytes(allowed_hex);
  //console.log("lo data", web3.utils.bytesToHex(th_data.concat(addr1_data).concat(addr2_data).concat(nonce_data).concat(expiry_data).concat(allowed_data)));
  const h1 = sha3.keccak256(th_data.concat(addr1_data).concat(addr2_data).concat(nonce_data).concat(expiry_data).concat(allowed_data));
  const h1_data = web3.utils.hexToBytes("0x"+h1);
  //h2
  const h2 = sha3.keccak256(d1_data.concat(ds_data).concat(h1_data));
  return "0x"+h2;
};

let makePermitIntSign = function(domain_sep, ntuser, spender, nonce) {
  const digest = permitDigest1(domain_sep, ntuser.addr, spender, nonce, 0, 1);
  const key = new ethers.utils.SigningKey(ntuser.prvk);
  const sig1 = key.signDigest(digest);
  return ethers.utils.joinSignature(sig1);
}

module.exports = {
  domainSep,
  makePermitExtSign,
  makePermitExtSignData,
  makeEipPermitExtSign,
  makeEipPermitExtSignData,
  makePermitIntSign,
  signTypedData
}
