// BAYR test suite
const Administration = artifacts.require("Administration");
const BitBayData = artifacts.require("BITBAY");
const BAYL = artifacts.require("BAYL");
const BAYR = artifacts.require("BAYR");
const BAYF = artifacts.require("BAYF");
const Pool = artifacts.require("Pool");
const UniswapV2Pair = artifacts.require("UniswapV2Pair");
const UniswapV2Factory = artifacts.require("UniswapV2Factory");
const UniswapV2Router02 = artifacts.require("UniswapV2Router02");
const WETH = artifacts.require("WETH9");
const TDAI = artifacts.require("TDAI");

const { expectRevert, time } = require('@openzeppelin/test-helpers');
require('chai')
  .use(require('chai-as-promised'))
  .should();

const timeadv_helper = require("./helpers/timeAdvHelper");
const permit_helper = require("./helpers/permitHelper");
const { assert } = require('chai');

function ether(n) { return new web3.utils.BN(web3.utils.toWei(n.toString(), 'ether')); }

let adm;
let bitbaydata;
let bayl;
let bayr;
let bayf;
let pool;
let router;
let factory;
let weth;
let tdai;
let tdelta = 0;
let init_code = "";
let pair_bayl_weth;
let pair_bayl_weth_addr;
let pair_bayl_tdai;
let pair_bayl_tdai_addr;

let init1 = async function() {
  adm = await Administration.deployed();
  bitbaydata = await BitBayData.deployed();
  bayl = await BAYL.deployed();
  bayr = await BAYR.deployed();
  bayf = await BAYF.deployed();
  pool = await Pool.deployed();
  router = await UniswapV2Router02.deployed();
  factory = await UniswapV2Factory.deployed();
  weth = await WETH.deployed();
  tdai = await TDAI.deployed();
};

contract('Trades', (accounts) => {
  const [owner, user1, user2, spender] = accounts;
  const ZERO_ADDRESS = '0x0000000000000000000000000000000000000000';

  beforeEach(async () => {
    if (bayr == null || bayr == undefined) {
      await init1();
    }
  });

  it('setup2', async () => {
    // for trades
    await router.changeProxy(bayl.address, bayr.address, pool.address, bitbaydata.address);
    // bitbay
    await adm.setProxy(bitbaydata.address);
    await bayl.setProxy(bitbaydata.address);
    await bayr.setProxy(bitbaydata.address);
    await bayf.setProxy(bitbaydata.address);
    await pool.setProxy(bitbaydata.address);
	  await pool.setProxies(bayl.address, bayr.address);
    await adm.changeLiquidityPool(pool.address);
    await bitbaydata.changeLiquidityPool(pool.address);
    await bitbaydata.changeProxy(bayl.address, true);
    await bitbaydata.changeProxy(bayr.address, true);
    await bitbaydata.changeProxy(bayf.address, true);
    await bitbaydata.changeRouter(router.address, true);
    await bitbaydata.changeMinter(adm.address);
    await bayl.setLiquidityPool(pool.address);
    await bayr.setLiquidityPool(pool.address);
    await bayl.changeMinter(adm.address);
    await bayr.changeMinter(adm.address);
    await bayf.changeMinter(adm.address);
  });

  it('setActive', async () => {
    await adm.setActive(true);
  });

  it('disableMinting', async () => { 
    await adm.disableMinting();
  });

  it('redeemTX', async () => { 
    const txid = "a627715744a9a5479fdabb5fa23570ffbb775d2814ae98b042c61eee4302e708";
    const sender = accounts[0];
    const reserve = [
      0,1000000000,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,1000000000,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0];
    const leaf = web3.utils.keccak256(web3.eth.abi.encodeParameters(
      ['address', 'uint256[38]', 'string'],
      [sender, reserve, txid]
    ));
    const root = leaf;
    await adm.addMerkle(root, 0);
    // wait 2x 43200
    await timeadv_helper.advanceTimeAndBlock(86400+100);
    tdelta += 86400+100;
    const proof = [];
    await adm.redeemTX(root, proof, reserve, txid);
    const balanceL = await bayl.balanceOf(accounts[0]);
    const balanceR = await bayr.balanceOf(accounts[0]);
    const balanceF = await bayf.balanceOf(accounts[0]);
    assert.equal(balanceL.toString(), "2000000000");
    assert.equal(balanceR.toString(), "0");
    assert.equal(balanceF.toString(), "0");
    // move peg
  });

  it('setSupply', async () => { 
    await adm.setSupply(40, []);
    await timeadv_helper.advanceTimeAndBlock(5400);
    tdelta += 5400;
    const balanceL = await bayl.balanceOf(accounts[0]);
    const balanceR = await bayr.balanceOf(accounts[0]);
    const balanceF = await bayf.balanceOf(accounts[0]);
    assert.equal(balanceL.toString(), "1000000000");
    assert.equal(balanceR.toString(), "1000000000");
    assert.equal(balanceF.toString(), "0");
  });

  it('transfer', async () => {
    const amount = web3.utils.toBN('100000000');
    await bayr.transfer(user1, amount, { from: owner });
    const balance = await bayf.balanceOf(user1);
    assert.equal(balance.toString(), amount.toString());
    const balanceL = await bayl.balanceOf(accounts[0]);
    const balanceR = await bayr.balanceOf(accounts[0]);
    const balanceF = await bayf.balanceOf(user1);
    assert.equal(balanceL.toString(), "1000000000");
    assert.equal(balanceR.toString(), "900000000");
    assert.equal(balanceF.toString(), "100000000");
  });
  
  it('init code', async () => {
    const code = await factory.INIT_CODE_PAIR_HASH();
    init_code = code;
    //assert.equal(code, "0x1fd0c524be5ca22ac7c85e61983f6e3acdf03e8d646ddcb3e0991c496fc91f93");
  });

  it('router vars', async () => {
    const vars = await router.showVariables();
    assert.equal(vars[0], bayl.address);
    assert.equal(vars[1], bayr.address);
    assert.equal(vars[2], pool.address);
    assert.equal(vars[3], bitbaydata.address);
    assert.equal(vars[4], accounts[0]);
  });

  it('create pair', async () => {
    await factory.createPair(bayl.address, weth.address);
    pair_bayl_weth_addr = await factory.getPair(bayl.address, weth.address);
    pair_bayl_weth = await UniswapV2Pair.at(pair_bayl_weth_addr);
  });

  it('set allowances', async () => {
    await bayl.approve(router.address, 10000000000, { from: accounts[0] });
    await bayr.approve(router.address, 10000000000, { from: accounts[0] });
    await tdai.approve(router.address, ether(100), { from: accounts[0] });
    await tdai.approve(router.address, ether(100), { from: accounts[1] });
    await tdai.transfer(accounts[1], ether(10), { from: accounts[0] });
  });

  it('pool balance', async () => {
    const vals = await pool.calculateBalance(accounts[0], pair_bayl_weth_addr, true, 0);
    // console.log(vals[0]);
    // console.log(vals[1]);
    // console.log(vals[2]);
  });

  it('checkAMM', async () => {
    //await pool.checkAMM(pair_bayl_weth);
    await bitbaydata.isAMMExchange(pair_bayl_weth_addr);
  });

  it('add liquidity', async () => {
    let bayl_val = 20000000; // 0.2 BAYL
    let bayr_val = 200000000;  // 2 BAYR
    let weth_val = ether(20);
    let perc = 1000; // 10% slippage
    const deadline = Math.floor(Date.now() / 1000) + tdelta + 1200;
    // args:
    // bayaddy,totalval,otherval,amount2min,amount1min,
    // currentaccount,deadline,exchange
    await router.addLiquidityETH(bayl.address, bayl_val+bayr_val, bayl_val, 
      perc, perc, // 1000 = 10%
      accounts[0], deadline, factory.address, { from: accounts[0], value: weth_val });

    {
      const balanceL = await bayl.balanceOf(pair_bayl_weth.address);
      assert.equal(balanceL.toString(), "20000000"); // 0.2 BAYL

      const balanceR = await bayr.balanceOf(pair_bayl_weth.address);
      assert.equal(balanceR.toString(), "200000000"); // 2 BAYR?

    }
  
  });

  it('check lp tokens balance', async () => {
    const balance = await pair_bayl_weth.balanceOf(accounts[0]);
    assert.equal(balance.toString(), "19999999999000");
  });

  // it('add liquidity 2', async () => {
  //
  // });

  it('remove liquidity', async () => {

    // lp tokens allowance
    await pair_bayl_weth.approve(router.address, ether(20), { from: accounts[0] });

    let lp_val = 9999999999500; // half of the lp tokens
    let perc = 1000; // 10% slippage
    const deadline = Math.floor(Date.now() / 1000) + tdelta + 1200;
    // args:
    // bayaddy,totalval,otherval,amount2min,amount1min,
    // currentaccount,deadline,exchange
    await router.removeLiquidityETH(bayl.address, lp_val, 
      perc, perc, // 1000 = 10%
      accounts[0], deadline, factory.address);
  });

  it('check lp tokens balance', async () => {
    const balance = await pair_bayl_weth.balanceOf(accounts[0]);
    assert.equal(balance.toString(), "9999999999500");
  });

  it('swap', async () => {

    {
      const balanceL = await bayl.balanceOf(pair_bayl_weth.address);
      assert.equal(balanceL.toString(), "10000000"); // 0.1 BAY
    }

    {
      const balanceW = await weth.balanceOf(pair_bayl_weth.address);
      assert.equal(balanceW.toString(), "10000000000500000000"); // 10 ETH
    }

    {
      const balanceL = await bayl.balanceOf(accounts[1]);
      assert.equal(balanceL.toString(), "0");
    }

    // current rate 0.1 BAYL = 10 ETH, 1 BAYL = 100 ETH, 1/100

    let bayl_val = 0; // BAY minimum to get
    let weth_val = ether(1);
    const deadline = Math.floor(Date.now() / 1000) + tdelta + 1200;
    // to get exact bay for exact my 1 ETH
    await router.swapExactETHForTokens(
      bayl_val, 
      [weth.address, bayl.address], 
      accounts[1], 
      deadline, 
      factory.address, 
      { from: accounts[1], value: weth_val }
    );

    {
      const balanceL = await bayl.balanceOf(accounts[1]);
      assert.equal(balanceL.toString(), "906610"); // 0.00906610 BAY
    }

    {
      const balanceL = await bayl.balanceOf(pair_bayl_weth.address);
      assert.equal(balanceL.toString(), "9093390"); // 0.0909339 BAY
    }

  });

  it('create pair with tdai', async () => {
    await factory.createPair(bayl.address, tdai.address);
    pair_bayl_tdai_addr = await factory.getPair(bayl.address, tdai.address);
    pair_bayl_tdai = await UniswapV2Pair.at(pair_bayl_tdai_addr);
  });

  it('checkAMM', async () => {
    //await pool.checkAMM(pair_bayl_weth);
    await bitbaydata.isAMMExchange(pair_bayl_tdai_addr);
  });

  it('add liquidity with tdai', async () => {
    let bayl_val = 20000000; // 0.2 BAYL
    let bayr_val = 200000000;  // 2 BAYR
    let tdai_val = ether(20);  // 20 TDAI
    let perc = 1000; // 10%
    const deadline = Math.floor(Date.now() / 1000) + tdelta + 1200;
    // args:
    // bayaddy,totalval,otherval,amount2min,amount1min,
    // currentaccount,deadline,exchange
    await router.addLiquidity([bayl.address, tdai.address], [bayl_val+bayr_val, tdai_val], 
      bayl_val, perc, perc, // 1000 = 10%
      accounts[0], deadline, factory.address);
  });

  it('check lp tokens balance tdai', async () => {
    const balance = await pair_bayl_tdai.balanceOf(accounts[0]);
    assert.equal(balance.toString(), "19999999999000");
  });

  it('swap tdai', async () => {

    {
      const balanceL = await bayl.balanceOf(pair_bayl_tdai.address);
      assert.equal(balanceL.toString(), "20000000"); // 0.2 BAY
    }

    {
      const balanceD = await tdai.balanceOf(pair_bayl_tdai.address);
      assert.equal(balanceD.toString(), "20000000000000000000"); // 20 TDAI
    }

    {
      const balanceL = await bayl.balanceOf(accounts[1]);
      assert.equal(balanceL.toString(), "906610"); // after swap1
    }

    // current rate 0.1 BAYL = 10 ETH, 1 BAYL = 100 ETH, 1/100

    let bayl_val = 0; // BAY minimum to get
    let tdai_val = ether(1);
    const deadline = Math.floor(Date.now() / 1000) + tdelta + 1200;
    // to get exact bay for exact my 1 ETH
    await router.swapExactTokensForTokens(
      tdai_val, bayl_val, 
      [tdai.address, bayl.address], 
      accounts[1], 
      deadline, 
      factory.address, 
      { from: accounts[1] }
    );

    {
      const balanceL = await bayl.balanceOf(accounts[1]);
      assert.equal(balanceL.toString(), "1856269"); // 0.01856269 BAY
    }

    {
      const balanceL = await bayl.balanceOf(pair_bayl_weth.address);
      assert.equal(balanceL.toString(), "9093390"); // 0.9093390 BAY
    }

  });

});
