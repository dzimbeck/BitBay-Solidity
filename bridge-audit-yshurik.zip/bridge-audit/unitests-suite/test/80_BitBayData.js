// Administration test suite

const Administration = artifacts.require("Administration");
const BitBayData = artifacts.require("BITBAY");
require('chai')
  .use(require('chai-as-promised'))
  .should()

const timeadv_helper = require("./helpers/timeAdvHelper");

function unit18(n) { return new web3.utils.BN(web3.utils.toWei(n.toString(), 'ether')); }

let adm;
let bitbay;

let init1 = async function() {
  adm = await Administration.deployed();
  bitbay = await BitBayData.deployed();
};

contract('BitBayData', (accounts) => {

  beforeEach(async function() {
    if (bitbay == null || bitbay == undefined) {
      await init1();
    }
  })


  it('name', async () => {
    const name = await bitbay.name();
    name.should.equal('BitBay Data');
  });

  it('minter', async () => {
    const minter = await bitbay.minter();
    minter.should.equal(accounts[0]);
  });

  it('totalSupply', async () => {
    const totalSupply = await bitbay.totalSupply();
    assert.equal(totalSupply.toString(), "100000000000000000");
  });

  it('advance 5400 seconds', async () => {
    await timeadv_helper.advanceTimeAndBlock(5400);
  });

  it('setSupply', async () => {
    {
      const supply = await bitbay.getSupply();
      //console.log("supply", supply.toString());
    }
    await bitbay.setSupply(1, { from: accounts[0] });
    const supply = await bitbay.getSupply();
    assert.equal(supply.toString(), "1");
  });

  it('getFrozen', async () => {
    const frozen = await bitbay.getFrozen(accounts[0]);
    //console.log("frozen", frozen.toString());
  });

});
