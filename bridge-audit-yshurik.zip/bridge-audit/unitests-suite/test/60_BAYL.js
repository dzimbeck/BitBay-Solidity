// Administration test suite

const Administration = artifacts.require("Administration");
const BitBayData = artifacts.require("BITBAY");
const BAYL = artifacts.require("BAYL");
const BAYR = artifacts.require("BAYR");
const BAYF = artifacts.require("BAYF");
const Pool = artifacts.require("Pool");
const { expectRevert, time } = require('@openzeppelin/test-helpers');
require('chai')
  .use(require('chai-as-promised'))
  .should()

const permit_helper = require("./helpers/permitHelper");
const { cshake128 } = require('js-sha3');

const timeadv_helper = require("./helpers/timeAdvHelper");

function unit18(n) { return new web3.utils.BN(web3.utils.toWei(n.toString(), 'ether')); }

let adm;
let bitbaydata;
let bayl;
let bayr;
let bayf;
let pool;

let init1 = async function() {
  adm = await Administration.deployed();
  bitbaydata = await BitBayData.deployed();
  bayl = await BAYL.deployed();
  bayr = await BAYR.deployed();
  bayf = await BAYF.deployed();
  pool = await Pool.deployed();
};

// EIP712 helper functions have been removed in favor of permit_helper

contract('BAYL', (accounts) => {
  const [owner, user1, user2, spender] = accounts;
  const ZERO_ADDRESS = '0x0000000000000000000000000000000000000000';

  beforeEach(async () => {
    // Deploy fresh instances for each test
    if (bayl == null || bayl == undefined) {
      await init1();
    }
  });

  it('changeMinter', async () => {
    await bayl.changeMinter(accounts[1], { from: accounts[0] });
  });

  it('changeMinter', async () => {
    await bayl.changeMinter(accounts[0], { from: accounts[1] });
  });

  it('changeMinter', async () => {
    await bayl.changeMinter(ZERO_ADDRESS, { from: accounts[0] });
  });

  it('setup2', async () => {
    await adm.setProxy(bitbaydata.address);
    await bayl.setProxy(bitbaydata.address);
    await bayr.setProxy(bitbaydata.address);
    await bayf.setProxy(bitbaydata.address);
    await pool.setProxy(bitbaydata.address);
    await adm.changeLiquidityPool(pool.address);
    await bitbaydata.changeLiquidityPool(pool.address);
    await bitbaydata.changeProxy(bayl.address, true);
    await bitbaydata.changeProxy(bayr.address, true);
    await bitbaydata.changeProxy(bayf.address, true);
    await bitbaydata.changeMinter(adm.address);
    await bayl.changeMinter(adm.address);
    await bayr.changeMinter(adm.address);
    await bayf.changeMinter(adm.address);
  });

  it('has correct name', async () => {
    const name = await bayl.name();
    name.should.equal('BitBay');
  });

  it('has correct symbol', async () => {
    const symbol = await bayl.symbol();
    symbol.should.equal('BAY');
  });

  it('has correct decimals', async () => {
    const decimals = await bayl.decimals();
    decimals.toString().should.equal('8');
  });

  it('has correct version', async () => {
    const version = await bayl.version();
    version.should.equal('1');
  });

  it('redeemTX', async () => { 
    const txid = "a627715744a9a5479fdabb5fa23570ffbb775d2814ae98b042c61eee4302e708";
    const sender = accounts[0];
    const reserve = [
      0,1000000,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,1000000,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0];
    const leaf = web3.utils.keccak256(web3.eth.abi.encodeParameters(
      ['address', 'uint256[38]', 'string'],
      [sender, reserve, txid]
    ));
    const root = leaf;
    await adm.addMerkle(root, 0);
    // wait 2x 43200
    await timeadv_helper.advanceTimeAndBlock(86400+100);
    const proof = [];
    await adm.redeemTX(root, proof, reserve, txid);
    const balanceL = await bayl.balanceOf(accounts[0]);
    const balanceR = await bayr.balanceOf(accounts[0]);
    const balanceF = await bayf.balanceOf(accounts[0]);
    assert.equal(balanceL.toString(), "2000000");
    assert.equal(balanceR.toString(), "0");
    assert.equal(balanceF.toString(), "0");
  });


  it('initializes showCirculating as false', async () => {
    const showCirculating = await bayl.showCirculating();
    showCirculating.should.equal(true);
  });

  it('checks liquidity pool address', async () => {
    const liquidityPool = await bayl.LiquidityPool();
    liquidityPool.should.equal(ZERO_ADDRESS);
  });


  it('returns total supply when showCirculating is false', async () => {
    const totalSupply = await bayl.totalSupply();
    assert.equal(totalSupply.toString(), "100000000000000000");
  });

  it('returns balance of address', async () => {
    const balance = await bayl.balanceOf(owner);
    assert(balance.toString() !== "0", "Balance should not be 0");
  });

  it('allows transfer between accounts', async () => {
    const amount = web3.utils.toBN('100000');
    await bayl.transfer(user1, amount, { from: owner });
    const balance = await bayl.balanceOf(user1);
    assert.equal(balance.toString(), amount.toString());
  });

  it('prevents transfer to zero address', async () => {
    const amount = web3.utils.toBN('100000');
    await expectRevert(
      bayl.transfer(ZERO_ADDRESS, amount, { from: owner }),
      'revert'
    );
  });

  it('allows approval and transferFrom', async () => {
    const amount = web3.utils.toBN('100000');
    await bayl.approve(spender, amount, { from: owner });      
    const allowance = await bayl.allowance(owner, spender);
    assert.equal(allowance.toString(), amount.toString());
    await bayl.transferFrom(owner, user2, amount, { from: spender });
    const balance = await bayl.balanceOf(user2);
    assert.equal(balance.toString(), amount.toString());
  });

  it('allows transfers to non-contract addresses', async () => {
    await bayl.checkAddress(user1, false);
    const checked = await bayl.checked(user1);
    assert.equal(checked.toString(), '0', "Non-contract address should be marked as checked");
  });

  // Skipping this test until we have proper mocking in place
  /*it('validates contract addresses', async () => {
    await bayl.checkAddress(bitbay.address, false);
    const checked = await bayl.checked(bitbay.address);
    assert.equal(checked.toString(), '1', "Contract address should be marked as checked");
  });*/

  it('handles sync parameter correctly', async () => {
    await bayl.checkAddress(user1, true);
    const checked = await bayl.checked(user1);
    assert.equal(checked.toString(), '0', "Sync parameter should not affect non-contract addresses");
  });

  it('caches check results', async () => {
    await bayl.checkAddress(user1, false);
    const checked = await bayl.checked(user1);
    assert.equal(checked.toString(), '0', "Check result should be cached");
  });

  it('check totalSupply', async () => {
    const totalSupply = await bayl.totalSupply();
    assert.equal(totalSupply.toString(), "100000000000000000");
  });

  let bayl_domain;
  let bayl_domain_sep;

  it('bayl domain separator', async () => {
    const d2 = await bayl.DOMAIN_SEPARATOR();
    const chainId = config.network == "soliditycoverage" ? 1 : await web3.eth.getChainId(); // warning: the network can be different during running coverage: 1 (soliditycoverage)
    const name = await bayl.name();
    const version = await bayl.version();
    bayl_domain_sep = permit_helper.domainSep(name, version, chainId, bayl.address);
    bayl_domain = { name: name, version: version, chainId: chainId, verifyingContract: bayl.address };
    assert.equal(bayl_domain_sep, d2, "domain separator");
  });

  const maxuint = "115792089237316195423570985008687907853269984665640564039457584007913129639935";
  function ether(n) { return new web3.utils.BN(web3.utils.toWei(n.toString(), 'ether')); }

  it('move-6-permit', async () => {
    const n1 = await bayl.nonces(accounts[0]);
    const sigp_tm = await permit_helper.makeEipPermitExtSignData(bayl_domain, accounts[0], accounts[2], n1, maxuint, 0);
    await bayl.approve(accounts[2], ether(0), { from: accounts[0] });
    await bayl.permit(accounts[0], accounts[2], maxuint, 0, sigp_tm.v, sigp_tm.r, sigp_tm.s, { from: accounts[3] });
    {
      const a1 = await bayl.allowance(accounts[0], accounts[2]);
      assert.equal(a1.toString(), maxuint, "match allowance of user0 for user2");
    }
  });


  it('accepts valid permit signature', async () => {
    const value = web3.utils.toBN('1000000000').toString();
    const deadline = Math.floor(Date.now() / 1000) + 3600 + 86400 + 100; // 1 hour from now
    const nonce = (await bayl.nonces(owner)).toString();      
    // Generate signature using permit_helper
    const sig = await permit_helper.makeEipPermitExtSignData(
      bayl_domain,
      owner,
      spender,
      nonce,
      value,
      deadline
    );
    // Call permit function with the generated signature
    await bayl.permit(owner, spender, value, deadline, sig.v, sig.r, sig.s);      
    // Check if allowance was set correctly
    const allowance = await bayl.allowance(owner, spender);
    assert.equal(allowance.toString(), value.toString(), "Allowance not set correctly after permit");
  });

  it('rejects expired permit', async () => {
    const value = web3.utils.toBN('1000000000').toString();
    const deadline = Math.floor(Date.now() / 1000) - 3600 +86400+100; // 1 hour in the past
    const nonce = (await bayl.nonces(owner)).toString();      
    // Generate signature using permit_helper
    const sig = await permit_helper.makeEipPermitExtSignData(
      bayl_domain,
      owner,
      spender,
      nonce,
      value,
      deadline
    );
    // Call permit function with the generated signature
    await expectRevert(
      bayl.permit(owner, spender, value, deadline, sig.v, sig.r, sig.s),
      'Permit-expired'
    );
  });

  it('rejects invalid signature', async () => {
    const value = web3.utils.toBN('1000000000');
    const deadline = Math.floor(Date.now() / 1000) + 3600 + 86400 + 100; // 1 hour from now
    
    // Use incorrect v, r, s values
    await expectRevert(
      bayl.permit(owner, spender, value, deadline, 27, '0x0000000000000000000000000000000000000000000000000000000000000000', '0x0000000000000000000000000000000000000000000000000000000000000000'),
      'Invalid-permit'
    );
  });

});
