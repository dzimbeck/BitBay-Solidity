// Administration test suite

const Administration = artifacts.require("Administration");
const BitBayData = artifacts.require("BITBAY");
const BAYL = artifacts.require("BAYL");
const BAYR = artifacts.require("BAYR");
const BAYF = artifacts.require("BAYF");
const Pool = artifacts.require("Pool");
require('chai')
  .use(require('chai-as-promised'))
  .should()

const timeadv_helper = require("./helpers/timeAdvHelper");

function unit18(n) { return new web3.utils.BN(web3.utils.toWei(n.toString(), 'ether')); }

let adm;
let bitbaydata;
let bayl;
let bayr;
let bayf;
let pool;

let init1 = async function() {
  adm = await Administration.deployed();
  bitbaydata = await BitBayData.deployed();
  bayl = await BAYL.deployed();
  bayr = await BAYR.deployed();
  bayf = await BAYF.deployed();
  pool = await Pool.deployed();
};

contract('Administration', (accounts) => {

  beforeEach(async function() {
    if (adm == null || adm == undefined) {
      await init1();
    }
  })

  it('setup1', async () => {
    await adm.setProxy(bitbaydata.address);
    await bayl.setProxy(bitbaydata.address);
    await bayr.setProxy(bitbaydata.address);
    await bayf.setProxy(bitbaydata.address);
    await pool.setProxy(bitbaydata.address);
    await adm.changeLiquidityPool(pool.address);
    await bitbaydata.changeLiquidityPool(pool.address);
    await bitbaydata.changeProxy(bayl.address, true);
    await bitbaydata.changeProxy(bayr.address, true);
    await bitbaydata.changeProxy(bayf.address, true);
    await bitbaydata.changeMinter(adm.address);
    await bayl.setLiquidityPool(pool.address);
    await bayr.setLiquidityPool(pool.address);
    await bayl.changeMinter(adm.address);
    await bayr.changeMinter(adm.address);
    await bayf.changeMinter(adm.address);
  });


  it('name', async () => {
    const name = await adm.name();
    name.should.equal('BitBay Community');
  });

  it('version', async () => {
    const version = await adm.version();
    version.should.equal('1');
  });

  it('minter', async () => {
    const minter = await adm.minter();
    minter.should.equal(accounts[0]);
  });

  it('mintmode', async () => {
    const mintmode = await adm.mintmode();
    assert.equal(mintmode.toString(), "1");
  });

  it('totalSupply', async () => {
    const totalSupply = await adm.totalSupply();
    assert.equal(totalSupply.toString(), "100000000000000000");
  });

  it ('totalMinted', async () => {
    const totalMinted = await adm.totalMinted();
    assert.equal(totalMinted.toString(), "0");
  });

  it('myweight', async () => {  
    const myweight = await adm.myweight(accounts[0]);
    assert.equal(myweight.toString(), "100");
  });

  it('isCurator', async () => {
    const isCurator = await adm.isCurator(accounts[0]);
    isCurator.should.equal(true);
  });

  it('curators', async () => {
    const curator = await adm.curators(0);
    curator.should.equal(accounts[0]);
  });

  it('totalvotes', async () => {
    const totalvotes = await adm.totalvotes();
    assert.equal(totalvotes.toString(), "100");
  });

  it('voteperc', async () => {
    const voteperc = await adm.voteperc();
    assert.equal(voteperc.toString(), "55");
  });

  it('votetimelimit', async () => {
    const votetimelimit = await adm.votetimelimit(0);
    assert.equal(votetimelimit.toString(), "5400");
  });
  
  it('proxy', async () => {
    const proxy = await adm.proxy();
    proxy.should.equal(bitbaydata.address);
  });

  it('lockProxies', async () => {
    await adm.lockProxies(1209601,3);
  });

  it('advance 5400 seconds', async () => {
    await timeadv_helper.advanceTimeAndBlock(1209600+100);
  });

  it('setActive', async () => {
    await adm.setActive(true);
  });

  it('mintNew', async () => { 
    await adm.mintNew(accounts[1], unit18(0.001));
  });

  it('disableMinting', async () => { 
    await adm.disableMinting();
  });

  it('register', async () => { 
    await adm.register("xxx");
  });

  it('redeemTX', async () => { 
    const txid = "a627715744a9a5479fdabb5fa23570ffbb775d2814ae98b042c61eee4302e708";
    const sender = accounts[0];
    const reserve = [
      0,1000000,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,1000000,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0];
    const leaf = web3.utils.keccak256(web3.eth.abi.encodeParameters(
      ['address', 'uint256[38]', 'string'],
      [sender, reserve, txid]
    ));
    const root = leaf;
    await adm.addMerkle(root, 0);
    // wait 2x 43200
    await timeadv_helper.advanceTimeAndBlock(86400+100);
    const proof = [];
    await adm.redeemTX(root, proof, reserve, txid);
    const balanceL = await bayl.balanceOf(accounts[0]);
    const balanceR = await bayr.balanceOf(accounts[0]);
    const balanceF = await bayf.balanceOf(accounts[0]);
    assert.equal(balanceL.toString(), "2000000");
    assert.equal(balanceR.toString(), "0");
    assert.equal(balanceF.toString(), "0");
  });

  it('setSupply', async () => { 
    await adm.setSupply(1, []);
    await timeadv_helper.advanceTimeAndBlock(5400);
    const balanceL = await bayl.balanceOf(accounts[0]);
    const balanceR = await bayr.balanceOf(accounts[0]);
    const balanceF = await bayf.balanceOf(accounts[0]);
    assert.equal(balanceL.toString(), "2000000");
    assert.equal(balanceR.toString(), "0");
    assert.equal(balanceF.toString(), "0");
  });

  it('redeemTX 2', async () => { 
    const txid = "a627715744a9a5479fdabb5fa23570ffbb775d2814ae98b042c61eee4302e709";
    const sender = accounts[0];
    const reserve = [
      1000000,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0];
    const leaf = web3.utils.keccak256(web3.eth.abi.encodeParameters(
      ['address', 'uint256[38]', 'string'],
      [sender, reserve, txid]
    ));
    const root = leaf;
    await adm.addMerkle(root, 1);
    // wait 2x 43200
    await timeadv_helper.advanceTimeAndBlock(86400+100);
    const proof = [];
    await adm.redeemTX(root, proof, reserve, txid);
    const balanceL = await bayl.balanceOf(accounts[0]);
    const balanceR = await bayr.balanceOf(accounts[0]);
    const balanceF = await bayf.balanceOf(accounts[0]);
    assert.equal(balanceL.toString(), "2875000");
    assert.equal(balanceR.toString(), "125000");
    assert.equal(balanceF.toString(), "0");
  });

  // burn, transfer to admin
  it('burn', async () => { 
    const minter = await bayl.minter();
    assert.equal(minter, adm.address);
    await bayl.transfer(minter, "100000");
  });

  // gets

  it('listNonces', async () => { 
    const nonces = await adm.listNonces(accounts[0]);
  });

  it('listNonces 2', async () => { 
    const nonces = await adm.listNonces(accounts[1]);
  });
  
  it('showReserve', async () => { 
    const reserve = await adm.showReserve(accounts[0], 0);
  });

  it('listHashes', async () => { 
    const hashes = await adm.listHashes(0);
  });

  it('showLimits', async () => { 
    const limits = await adm.showLimits();
  });

  it('merkleLen', async () => { 
    const merkleLen = await adm.merkleLen();
  });

  it('showReserve 2', async () => { 
    const reserve = await adm.showReserve(accounts[1], 0);
  });

  // misc

  it('changeMinter', async () => { 
    await adm.changeMinter(accounts[1]);
    await adm.changeMinter(accounts[0], { from: accounts[1] });
  });

  it('changeAdminMinter', async () => { 
    await adm.changeAdminMinter(bayl.address, accounts[1]);
    await timeadv_helper.advanceTimeAndBlock(7257601);
    await adm.changeAdminMinter(bayl.address, adm.address);
  });

  it('changeBAYProxy', async () => { 
    await timeadv_helper.advanceTimeAndBlock(7257601);
    await adm.changeBAYProxy(accounts[1], false);
  });

  it('changeRouter', async () => { 
    await timeadv_helper.advanceTimeAndBlock(7257601);
    await adm.changeRouter(accounts[1], false);
  });

  it('setLiquidityPool', async () => { 
    await timeadv_helper.advanceTimeAndBlock(7257601);
    await adm.setLiquidityPool(bayl.address, accounts[1]);
  });

  it('changeTargetProxy', async () => { 
    await timeadv_helper.advanceTimeAndBlock(7257601);
    await adm.changeTargetProxy(bayl.address, accounts[1]);
  });

  it('enableSpecial', async () => { 
    await adm.enableSpecial(true);
  });

  it('setAutomaticUnfreeze', async () => { 
    await adm.setAutomaticUnfreeze(true);
  });

  it('setvoteperc', async () => { 
    await adm.setvoteperc(54);
  });

  it('changeProposalTimeLimit', async () => { 
    await adm.changeProposalTimeLimit(0, 5300);
  });

  it('updateProxies', async () => { 
    await timeadv_helper.advanceTimeAndBlock(7257601);
    await adm.updateProxies();
  });

});
