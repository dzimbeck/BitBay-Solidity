module.exports = {
  client: require('ganache-cli'),
  providerOptions: {
	  keepAliveTimeout: 300000
  },
  skipFiles: ['Halo.sol','WETH.sol','ERC20.sol','IERC20.sol','TDAI.sol','Permit.sol'],
}
