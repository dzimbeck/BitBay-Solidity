console.log("Deploying contracts... (1)");

const Administration = artifacts.require("Administration");
console.log("Administration artifact loaded");
const BitBayData = artifacts.require("BITBAY");
console.log("BitBayData artifact loaded");
const BAYF = artifacts.require("BAYF");
console.log("BAYF artifact loaded");
const BAYL = artifacts.require("BAYL");
console.log("BAYL artifact loaded");
const BAYR = artifacts.require("BAYR");
console.log("BAYR artifact loaded");
const Pool = artifacts.require("Pool");
console.log("Pool artifact loaded");
const Permit = artifacts.require("Permit");
console.log("Permit artifact loaded");
const WETH = artifacts.require("WETH9");
console.log("WETH artifact loaded");
const TDAI = artifacts.require("TDAI");
console.log("TDAI artifact loaded");
const mintLib = artifacts.require("mintLib");
console.log("mintLib artifact loaded");
const UniswapV2Factory = artifacts.require("UniswapV2Factory");
console.log("UniswapV2Factory artifact loaded");
const UniswapV2Router02 = artifacts.require("UniswapV2Router02");
console.log("UniswapV2Router02 artifact loaded");

module.exports = async function(deployer, network, accounts) {
  console.log("Deploying Administration...");
  await deployer.deploy(Administration).catch(error => console.error(error));
  var dsize1 = (Administration.deployedBytecode.length / 2) - 1 ;
  console.log("Administration dsize:", dsize1);

  console.log("Deploying BitBayData...");
  await deployer.deploy(BitBayData);
  var dsize2 = (BitBayData.deployedBytecode.length / 2) - 1 ;
  console.log("BitBayData dsize:", dsize2);

  console.log("Deploying BAYF...");
  await deployer.deploy(BAYF);
  var dsize3 = (BAYF.deployedBytecode.length / 2) - 1 ;
  console.log("BAYF dsize:", dsize3);

  console.log("Deploying BAYL...");
  await deployer.deploy(BAYL);
  var dsize4 = (BAYL.deployedBytecode.length / 2) - 1 ;
  console.log("BAYL dsize:", dsize4);

  console.log("Deploying BAYR...");
  await deployer.deploy(BAYR);
  var dsize5 = (BAYR.deployedBytecode.length / 2) - 1 ;
  console.log("BAYR dsize:", dsize5);

  console.log("Deploying Pool...");
  await deployer.deploy(Pool);
  var dsize6 = (Pool.deployedBytecode.length / 2) - 1 ;
  console.log("Pool dsize:", dsize6);

  console.log("Deploying Permit...");
  await deployer.deploy(Permit);
  var dsize7 = (Permit.deployedBytecode.length / 2) - 1 ;
  console.log("Permit dsize:", dsize7);

  console.log("Deploying UniswapV2Factory...");
  const factory = await deployer.deploy(UniswapV2Factory, Administration.address);
  var dsize8 = (UniswapV2Factory.deployedBytecode.length / 2) - 1 ;
  console.log("UniswapV2Factory dsize:", dsize8);

  console.log("Deploying WETH...");
  const weth = await deployer.deploy(WETH);
  var dsize9 = (WETH.deployedBytecode.length / 2) - 1 ;
  console.log("WETH dsize:", dsize9);

  console.log("Deploying TDAI...");
  const tdai = await deployer.deploy(TDAI);
  var dsize10 = (TDAI.deployedBytecode.length / 2) - 1 ;
  console.log("TDAI dsize:", dsize10);

  // address _factory, address _WETH, address _minter, bytes memory init, uint mynumerator, uint fnum, uint fden
  const init_code = await factory.INIT_CODE_PAIR_HASH();
  console.log("init_code:", init_code);
  await deployer.deploy(mintLib);
  await deployer.link(mintLib, UniswapV2Router02);
  await deployer.deploy(UniswapV2Router02, factory.address, weth.address, accounts[0], init_code, 997, 1, 5);
  var dsize9 = (UniswapV2Router02.deployedBytecode.length / 2) - 1 ;
  console.log("UniswapV2Router02 dsize:", dsize9);

};
